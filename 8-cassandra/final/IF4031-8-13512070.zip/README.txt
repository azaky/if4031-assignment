Tugas 8 IF4031 - Pengembangan Aplikasi Terdistribusi : Pemrograman Cassandra

Anggota Kelompok:
- 13512070 - Willy
- 13512076 - Ahmad Zaky

Cara menjalankan:
- Jalankan program dengan perintah "java -jar apache-cassandra.jar". File jar ada pada folder bin
- Perintah yang dapat dilakukan:
    - register <username> <password>: Meregister user baru
    - login <username> <password>: Login dengan akun yang sudah ada
    - follow <username>: Menjadi follower dari <username>
    - tweet <body>: Membuat tweet dengan isi <body>
    - show tweet <username>: Melihat tweet yang dibuat <username>
    - show timeline: Melihat timeline sendiri (yang berisi tweet2 orang yang kita follow)

